/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Félix Gómez
 */
@Entity
@Table(name = "requerimientos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Requerimientos.findAll", query = "SELECT r FROM Requerimientos r")
    , @NamedQuery(name = "Requerimientos.findByIdRequerimiento", query = "SELECT r FROM Requerimientos r WHERE r.idRequerimiento = :idRequerimiento")
    , @NamedQuery(name = "Requerimientos.findByTitulo", query = "SELECT r FROM Requerimientos r WHERE r.titulo = :titulo")
    , @NamedQuery(name = "Requerimientos.findByDescripcion", query = "SELECT r FROM Requerimientos r WHERE r.descripcion = :descripcion")
    , @NamedQuery(name = "Requerimientos.findByDimension", query = "SELECT r FROM Requerimientos r WHERE r.dimension = :dimension")})
public class Requerimientos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "id_requerimiento")
    private String idRequerimiento;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "titulo")
    private String titulo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "dimension")
    private String dimension;
    @JoinColumn(name = "id_funcion", referencedColumnName = "id_funcion")
    @ManyToOne(optional = false)
    private Funciones idFuncion;
    @JoinColumn(name = "id_prioridad", referencedColumnName = "id_prioridad")
    @ManyToOne(optional = false)
    private Prioridades idPrioridad;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idRequerimiento")
    private Collection<Actividades> actividadesCollection;

    public Requerimientos() {
    }

    public Requerimientos(String idRequerimiento) {
        this.idRequerimiento = idRequerimiento;
    }

    public Requerimientos(String idRequerimiento, String titulo, String descripcion, String dimension) {
        this.idRequerimiento = idRequerimiento;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.dimension = dimension;
    }

    public String getIdRequerimiento() {
        return idRequerimiento;
    }

    public void setIdRequerimiento(String idRequerimiento) {
        this.idRequerimiento = idRequerimiento;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public Funciones getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(Funciones idFuncion) {
        this.idFuncion = idFuncion;
    }

    public Prioridades getIdPrioridad() {
        return idPrioridad;
    }

    public void setIdPrioridad(Prioridades idPrioridad) {
        this.idPrioridad = idPrioridad;
    }

    @XmlTransient
    public Collection<Actividades> getActividadesCollection() {
        return actividadesCollection;
    }

    public void setActividadesCollection(Collection<Actividades> actividadesCollection) {
        this.actividadesCollection = actividadesCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRequerimiento != null ? idRequerimiento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Requerimientos)) {
            return false;
        }
        Requerimientos other = (Requerimientos) object;
        if ((this.idRequerimiento == null && other.idRequerimiento != null) || (this.idRequerimiento != null && !this.idRequerimiento.equals(other.idRequerimiento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Requerimientos[ idRequerimiento=" + idRequerimiento + " ]";
    }
    
}
